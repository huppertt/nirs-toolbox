function rowNames = variableEditorRowNames(this)
%   This function is undocumented and will change in a future release

% Undocumented method used by the Variable Editor to determine the names of
% dataset rows.

%   Copyright 2011 The MathWorks, Inc.

rowNames = this.Properties.ObsNames;