function y = createEmptyVar(n,x)
% Create class(x).empty(n,0))
y = x(zeros(n,0));
