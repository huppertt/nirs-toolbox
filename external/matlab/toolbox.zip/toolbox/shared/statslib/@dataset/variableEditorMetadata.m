function currFormat = variableEditorMetadata(~)
% This function is undocumented and will change in a future release

% Retrieves the format for any datetime columns in the table, which
% is needed for the variable editor.

% Copyright 2014 The MathWorks, Inc.

% As an encouragement to move toward using the Table dataType, 
% datetime Format will not be supported in Dataset objects
currFormat = [];
end

