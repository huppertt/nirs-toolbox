function [types,metaRows,emptyTrailing] = detectTypes(typeIDs,emptyColumnType,metaRows)
% Copyright 2016-2017 The MathWorks, Inc.
    persistent enum
    persistent typenames
    
    if isempty(typenames)
        enum.NUMBER = matlab.io.spreadsheet.internal.Sheet.NUMBER;
        enum.STRING = matlab.io.spreadsheet.internal.Sheet.STRING;
        enum.DATETIME = matlab.io.spreadsheet.internal.Sheet.DATETIME;
        enum.BOOLEAN = matlab.io.spreadsheet.internal.Sheet.BOOLEAN;
        enum.EMPTY = matlab.io.spreadsheet.internal.Sheet.EMPTY;
        enum.BLANK = matlab.io.spreadsheet.internal.Sheet.BLANK;
        enum.ERROR = matlab.io.spreadsheet.internal.Sheet.ERROR;
        % enum.DURATION = matlab.io.spreadsheet.internal.Sheet.DURATION;
        % these names are in the same position as the enum number value, the ''
        % values correspond to empty, blank and error.
        typenames = {'double','char','datetime','logical','','','','duration'};
    end
    
    % Find the trailing columns which do not contain data.
    emptyTrailing = find(~all(typeIDs==enum.EMPTY|typeIDs==enum.BLANK,1),1,'last')+1;
    
    if nargin <= 2
        textmask = (typeIDs == enum.STRING)|...
            (typeIDs == enum.BLANK)|...
            (typeIDs == enum.ERROR)|...
            (typeIDs == enum.EMPTY);
        
        % find the first row that doesn't contain all strings/blanks/errors
        metaRows = min([size(typeIDs,1),find(~all(textmask,2),1)-1]);
        
        if metaRows == size(typeIDs,1)
            metaRows = min(size(typeIDs,1),1); % always include varname line
            types = typenames(repmat(enum.STRING,1,size(typeIDs,2)));
            return
        end
    end
    
    % Convert to double to add NaNs to take advantage of MODE ignoring NaN
    typeIDs = double(typeIDs);
    % Ignore all these
    typeIDs(typeIDs == enum.BLANK | typeIDs == enum.ERROR | typeIDs == enum.EMPTY) = NaN;
    dominateType = mode(typeIDs((metaRows+1):end,:),1);
    
    % An entirely empty column should be number or string dependent on
    % whether the function call is made from readtable/datastore, or
    % detectImportOptions, respectively
    if ~isempty(emptyColumnType) && strcmp(emptyColumnType,'double')
        dominateType(isnan(dominateType)) = enum.NUMBER;
    else
        dominateType(isnan(dominateType)) = enum.STRING;
    end

    types = typenames(dominateType);
    if all(typeIDs(1,:) == dominateType)
        metaRows = 0;
    end

end