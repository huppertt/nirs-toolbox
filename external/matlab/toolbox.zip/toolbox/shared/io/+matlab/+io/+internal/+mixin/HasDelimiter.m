classdef (HandleCompatible) HasDelimiter
%HASDELIMITER a text.mixin class for the Delimiter property

% Copyright 2016 The MathWorks, Inc.
    
    properties (Dependent)
        %DELIMITER used to parse text into fields.
        % Delimiter can be a character vector or cell array of character
        % vectors (e.g. ',', {' ','\t'}
        Delimiter
    end
    
    properties (Access = private)
        % This contains interpreted characters, not the escape sequences
        delim_ = {','};
    end
    
    methods
        function obj = set.Delimiter(obj,delimiter)
            delimiter = convertStringsToChars(delimiter);
            delimiter = matlab.io.internal.utility.validateAndEscapeCellStrings(delimiter,'Delimiter');
            obj.delim_ = unique(delimiter);
        end
        
        function delimiter = get.Delimiter(obj)
            % char array might be row or column, don't bother trying to 
            % keep the state fixed as a column, but reorient it on return.
            % This will always produce a row.
            delimiter = matlab.io.internal.utility.unescape(obj.delim_(:)'); 
        end
    end
end
