classdef VariableImportOptions < matlab.io.internal.mixin.HasPropertiesAsNVPairs ...
        & matlab.mixin.CustomDisplay ...
        & matlab.mixin.Heterogeneous
    %VARIABLEIMPORTOPTIONS Options for importing a variable from a file
    %
    %   VariableImportOptions Properties:
    %               Name - The name of the variable on import
    %               Type - The data type of the variable on import
    %          FillValue - A scalar value to fill missing or unconvertible data 
    %     TreatAsMissing - Text which is used in a file to represent missing
    %                      data, e.g. 'NA'
    %     EmptyFieldRule - How to treat empty field data
    %          QuoteRule - How to treat quoted text.
    %           Prefixes - Prefix characters to be removed from variable on
    %                      import
    %           Suffixes - Suffix characters to be removed from variable on
    %                      import
    %
    % See also
    %   readtable, datastore, matlab.io.spreadsheet.SpreadsheetImportOptions
    %   matlab.io.TextVariableImportOptions
    %   matlab.io.NumericVariableImportOptions
    %   matlab.io.LogicalVariableImportOptions
    %   matlab.io.DatetimeVariableImportOptions
    %   matlab.io.DurationVariableImportOptions
    %   matlab.io.CategoricalVariableImportOptions
    
    % Copyright 2016-2018 The MathWorks, Inc.
    properties (Access = private)
        Name_ = '';
    end
    properties (Dependent)
            %NAME
        %   Name of the variable to be imported. Must be a valid identifier.
        %
        % See also matlab.io.VariableImportOptions
        Name
    end
    properties

        %QUOTERULE
        %   How surrounding quotes in text should be treated.
        %
        %   'remove' - If converting from text, and the field begins with a double
        %              quotation mark ("), omit the leading quotation mark and its
        %              accompanying closing mark, which is the second instance of a
        %              lone double quotation mark. Replace escaped double quotation
        %              marks (for example, ""abc"") with lone double quotation
        %              marks ("abc"). Ignore any double quotation marks that appear
        %              after the closing double quotation mark.
        %
        %   'keep'   - retain all quote marks. NOTE: This may cause conversion to
        %              fail for some types.
        %
        %   'error'  - Report an error when converting data which begins with a
        %              double-quote character ("). Use this setting if the field
        %              should never be quoted.
        %
        % See also matlab.io.VariableImportOptions
        QuoteRule = 'remove';

        %TREATASMISSING
        %   A cell array of character vectors which are to be treated as missing
        %   indicators for the variable when importing text data. When a missing
        %   indicator is found, the MissingRule is used to determine the
        %   appropriate action.
        %
        %   Example, set the options to replace occurrences of 'NA' with '-':
        %
        %       % when ImportOptions/MissingRule = 'fill'
        %       opts = matlab.io.TextVariableImportOptions();
        %       opts.TreatAsMissing = {'NA'};
        %       opts.FillValue = '-';
        %
        %   When importing, any instances of 'NA' will be replaced with '-'
        %
        % See also matlab.io.VariableImportOptions
        %   matlab.io.spreadsheet.SpreadsheetImportOptions/MissingRule
        %   matlab.io.spreadsheet.SpreadsheetImportOptions/ImportErrorRule
        %   matlab.io.VariableImportOptions/FillValue
        TreatAsMissing = {};

        %PREFIXES
        %   A cell array of character vectors or a string vector containing
        %   the prefix characters that need to be removed from the
        %   variable on import.
        %
        % See also matlab.io.VariableImportOptions
        Prefixes = {};

        %SUFFIXES
        %   A cell array of character vectors or a string vector containing
        %   the suffix characters that need to be removed from the
        %   variable on import.
        %
        % See also matlab.io.VariableImportOptions
        Suffixes = {};

        %EMPTYFIELDRULE Procedure to manage empty variable fields
        %
        %   'missing' - treat empty fields as missing data and follow the
        %               procedure specified in the MissingRule property.
        %
        %   'error'   - treat empty fields as import errors and follow the
        %               procedure specified in the ImportErorrRule
        %               property.
        %
        %   'auto'    - convert empty fields to type-specific values. 
        %               For example, when variable is of type:
        %
        %               text                 - import as zero length char 
        %                                      or string
        %               numeric: 
        %                  1) floating-point - import as NaN
        %                  2) integer        - import as 0
        %               duration             - import as NaN
        %               categorical          - import as <undefined>
        %               datetime             - import as NaT
        %               logical              - import as false
        %
        % See also matlab.io.VariableImportOptions
        %   matlab.io.spreadsheet.SpreadsheetImportOptions/ImportErrorRule
        %   matlab.io.VariableImportOptions/FillValue
        %   matlab.io.spreadsheet.SpreadsheetImportOptions/MissingRule
        EmptyFieldRule = 'missing';
    end

    properties (Abstract)
        %TYPE
        %   The input type of the variable when imported.
        %
        % See also matlab.io.VariableImportOptions
        Type

        %FILLVALUE
        %   Used as a replacement value when ErrorRule = 'fill' or
        %   MissingRule = 'fill'. The valid types depend on the value of TYPE.
        %
        % See also matlab.io.VariableImportOptions
        %   matlab.io.spreadsheet.SpreadsheetImportOptions/MissingRule
        %   matlab.io.spreadsheet.SpreadsheetImportOptions/ImportErrorRule
        %   matlab.io.VariableImportOptions/Type
        FillValue
    end

    methods (Static, Sealed, Access = protected)
        function elem = getDefaultScalarElement()
            elem = matlab.io.TextVariableImportOptions();
        end
    end

    methods (Sealed, Access=?matlab.io.ImportOptions)
        function obj = setType(obj,idx,types)
            tf = ismember(types,matlab.io.internal.supportedTypeNames());

            if ~all(tf)
                error(message('MATLAB:textio:io:UnsupportedConversionType',types{find(~tf,1)}));
            end
            % Convert the selection to the requested types.
            for i = 1:numel(idx)
                obj(idx(i)) = convertOptsToType(obj(idx(i)),types{i});
            end
        end
    end

    % get/set functions
    methods
        function obj = set.QuoteRule(obj,rhs)
            obj.QuoteRule = validatestring(rhs,{'remove','keep','error'});
        end
        function obj = set.Name(obj,rhs)
            if ~(isempty(rhs) || isvarname(rhs))
                if ischar(rhs)
                    error(message('MATLAB:table:VariableNameNotValidIdentifier',rhs));
                else
                    error(message('MATLAB:textio:textio:InvalidStringProperty','Name'));
                end
            end
            obj.Name_ = convertStringsToChars(rhs);
        end
        function val = get.Name(opts)
            val = opts.Name_;
        end
        function obj = set.TreatAsMissing(obj,rhs)
            rhs = convertStringsToChars(rhs);
            if ischar(rhs)
                rhs = {rhs};
            end
            obj.TreatAsMissing = rhs;
            if ~iscellstr(obj.TreatAsMissing)
                error(message('MATLAB:datastoreio:tabulartextdatastore:invalidTreatAsMissing'))
            end
        end
        function val = get.TreatAsMissing(obj)
            val = obj.TreatAsMissing;
            if isempty(val)
                val = {};
            end 
        end
        function val = get.Prefixes(obj)
            val = obj.Prefixes;
        end
        function obj = set.Prefixes(obj, val)
            if iscellstr(val) || isstring(val) || ischar(val)
                val = convertStringsToChars(val);
                if iscellstr(val)
                    [~,idx] = sort(cellfun(@(x)length(x),val),'descend');
                    val = val(idx);
                end
                obj.Prefixes = val;
            else
                error(message('MATLAB:textio:textio:InvalidPrefixes'));
            end
        end
        function val = get.Suffixes(obj)
            val = obj.Suffixes;
        end
        function obj = set.Suffixes(obj, val)
            if iscellstr(val) || isstring(val) || ischar(val)
                val = convertStringsToChars(val);
                if iscellstr(val)
                    [~,idx] = sort(cellfun(@(x)length(x),val),'descend');
                    val = val(idx);
                end
                obj.Suffixes = val;
            else
                error(message('MATLAB:textio:textio:InvalidSuffixes'));
            end
        end
        function obj = set.EmptyFieldRule(obj,rhs)
            obj.EmptyFieldRule = validatestring(rhs,{'missing','error','auto'});
        end
    end

    % Custom Display Methods
    methods (Sealed, Access = protected)
        function propgrp = getPropertyGroups(obj)
            if ~isscalar(obj)
                propgrp = getPropertyGroups@matlab.mixin.CustomDisplay(obj);
            else
                props.Name            = obj.Name_;
                props.Type            = obj.Type;
                props.FillValue       = obj.FillValue;
                props.TreatAsMissing  = obj.TreatAsMissing;
                props.QuoteRule       = obj.QuoteRule;
                props.Prefixes        = obj.Prefixes;
                props.Suffixes        = obj.Suffixes;
                props.EmptyFieldRule  = obj.EmptyFieldRule;

                propgrp(1) = matlab.mixin.util.PropertyGroup(props,'Variable Properties:');
                
                [type_specific,group_name] = obj.getTypedPropertyGroup();
                
                propgrp(2) = matlab.mixin.util.PropertyGroup(type_specific,group_name);
            end
        end

        function h = getHeader(obj)
            h = getHeader@matlab.mixin.CustomDisplay(obj);
        end

        function f = getFooter(obj)
            f = getFooter@matlab.mixin.CustomDisplay(obj);
        end

        function displayEmptyObject(obj)
            displayEmptyObject@matlab.mixin.CustomDisplay(obj);
        end

        function displayNonScalarObject(obj)

            try
                isdesktop = usejava('desktop') && desktop('-inuse');
            catch
                isdesktop = false;
            end

            if ~isrow(obj) || ~isdesktop
                displayNonScalarObject@matlab.mixin.CustomDisplay(obj);
                return;
            end

            if matlab.internal.display.isHot()
                name = '<a href="matlab:helpPopup matlab.io.VariableImportOptions" style="font-weight:bold">VariableImportOptions</a>';
            else
                name = 'VariableImportOptions';
            end

            propNames = {'Name';'Type';'FillValue';'TreatAsMissing';'EmptyFieldRule'; ...
                'QuoteRule';'Prefixes';'Suffixes'};
            s = struct(propNames{1},{obj.Name},propNames{2},{obj.Type},propNames{3},{obj.FillValue}, ...
                propNames{4},{obj.TreatAsMissing},propNames{5},{obj.EmptyFieldRule}, ...
                propNames{6},{obj.QuoteRule},propNames{7},{obj.Prefixes},propNames{8},{obj.Suffixes});
            dispData = getDisplayCell(obj,name,s);

            dispData = [propNames,dispData];
            sz = cellfun(@numel,dispData);
            column_width = max(sz);
            sz = size(dispData);
            fprintf('   Variable Options:\n                 ')
            arrayfun(@(n)fprintf(sprintf('   %%%ds',column_width(n)),sprintf('(%d) |',n-1)),2:sz(2)-1);
            fprintf(sprintf('   %%%ds',column_width(sz(2))),sprintf('(%d)  ',sz(2)-1));
            fprintf('\n')

            for i = 1:sz(1)
                col_name = dispData{i,1};
                fprintf(sprintf('  %%%ds: ',column_width(1)),col_name);
                col_data = dispData(i,2:end);
                for j = 1:(sz(2)-2)
                    fprintf(sprintf('%%%ds | ',column_width(j+1)),col_data{j});
                end
                fprintf(sprintf('%%%ds',column_width(sz(2))),col_data{sz(2)-1});
                fprintf('\n')
            end
            strHelpGetvaropts = '<a href="matlab:helpPopup getvaropts" style="font-weight:regular">getvaropts</a>';
            fprintf(['\n\t', getString(message('MATLAB:textio:io:GetvaroptsLink')), ' ',strHelpGetvaropts, '\n']);
        end
    end

    % For child class to do custom display
    methods (Abstract, Access = protected)
        [type_specific,group_name] = getTypedPropertyGroup(obj);
    end

    methods (Sealed, Hidden, Access = protected)
        function strs = handleQuotes(obj,strs)          
            if strcmp(obj.QuoteRule,'keep')
                return
            end
            quoted = startsWith(strip(strs),'"');
            if any(quoted(:))
                if strcmp(obj.QuoteRule,'error') 
                    error(message('MATLAB:textio:io:QuoteRuleErrorSpreadsheet',strs{find(quoted(:),1)}))
                else
                    strs(quoted) = regexprep(strs(quoted),'^(\s*)"(""|[^"])*"?','$1${strrep($2,''""'',''"'')}');
                end
            end
        end
    end

    methods (Sealed,Static,Hidden)
        function obj = getTypedOptionsByName(newType)
            switch newType
                case {'double','single','int8','uint8','int16','uint16','int32','uint32','int64','uint64'}
                    obj = matlab.io.NumericVariableImportOptions('Type',newType);
                case {'char','string'}
                    obj = matlab.io.TextVariableImportOptions('Type',newType);
                case 'datetime'
                    obj = matlab.io.DatetimeVariableImportOptions();
                case 'duration'
                    obj = matlab.io.DurationVariableImportOptions();
                case 'categorical'
                    obj = matlab.io.CategoricalVariableImportOptions();
                case 'logical'
                    obj = matlab.io.LogicalVariableImportOptions();
                otherwise
                    assert(false);
            end
        end
    end

    methods (Access = private)
        function obj = convertOptsToType(obj,type)
            % Set the shared properties
            persistent sharedProperties
            if isempty(sharedProperties)
                meta = ?matlab.io.VariableImportOptions;
                sharedProperties = {meta.PropertyList.Name};
                sharedProperties([meta.PropertyList.Abstract]) = [];
            end

            try
                obj.Type = type;
            catch 
                oldobj = obj;
                % First get an object of the new type
                obj = matlab.io.VariableImportOptions.getTypedOptionsByName(type);
                % Assign old properties into new properties.
                for p = sharedProperties
                    obj.(p{:}) =  oldobj.(p{:});
                end
            end
        end
    end

    methods (Hidden, Sealed)
        function opts = setNames(opts,names)
            % avoid validating names
            if ~isempty(names)
                ids = ~strcmp(names,{opts.Name_});
                [opts(ids).Name_] = names{ids};
            end
        end
        function names = getNames(opts)
            % avoid validating names
            names = {opts.Name_};
        end
    end
end

function d = getDisplayCell(obj,name,s)
    % using message catalog to display the variable options
    str = "  1x";
    fprintf('  %s\n\n',getString(message('MATLAB:ObjectText:DISPLAY_AND_DETAILS_ARRAY_WITH_PROPS', str + numel(obj),name)));
    T = struct2table(s); %#ok<NASGU>
    td = evalc('disp(T)');
    td = splitlines(td);

    td(strlength(td)==0) = [];% remove empty lines in the display
    td = replace(td,{'</strong>','<strong>'},''); % strong tags change the length of fields, we need to take them out.
    td = extractAfter(td(2:end),'    '); % remove the leading four spaces from table display
    widths = strlength(split(td(1))); % Split the underscores by whitespace
    widths(widths==0) =[]; % remove any zero length widths.
    widths(1:end-1) = widths(1:end-1) + 4;
    td = join(td(2:end),newline,1); % Rejoin the remaining lines to parse
    d = textscan(td{1},sprintf('%%%dc',widths),'Whitespace','','Delimiter','','EndOfLine','\n');
    d = cellfun(@cellstr,d,'UniformOutput',false);
    for kk = 1:numel(d{3}) % Cell data is contained in [], remove those.
        if (d{3}{kk}(1) == '[')
            d{3}{kk}([1 end]) = [];
            d{3} = strtrim(d{3});
        end
        d{4}{kk} = dispCellProps(d{4}{kk});
        d{7}{kk} = dispCellProps(d{7}{kk});
        d{8}{kk} = dispCellProps(d{8}{kk});
    end
    d = [d{:}]'; % Put the new data back together in the way we want to display it
end

function dispCell = dispCellProps(dispCell)
    if ~contains(dispCell,'[') && ~strcmp(strtrim(dispCell),'{}')
        dispCell = ['{', replace(dispCell,'    ',','), '}'];
    end
end
