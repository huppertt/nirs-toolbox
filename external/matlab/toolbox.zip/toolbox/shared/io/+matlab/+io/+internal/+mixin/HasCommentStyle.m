classdef (HandleCompatible) HasCommentStyle
%HASDELIMITER a text.mixin class for the Delimiter property

% Copyright 2016 The MathWorks, Inc.
    
    properties (Dependent)
        %COMMENTSTYLE Symbol(s) designating text to ignore.
        % Specify a single string (such as '%') to ignore characters
        % following the string on the same line. Specify a cell array of
        % two strings (such as {'/*', '*/'}) to ignore characters between
        % the strings. Comments are only checked at the start of each
        % field, not within a field.
        CommentStyle
    end
    
    properties (Access = private)
        comments_ = {};
    end
    
    methods
        function opts = set.CommentStyle(opts,rhs)
            rhs = convertStringsToChars(rhs);
            rhs = matlab.io.internal.utility.validateAndEscapeCellStrings(rhs,'CommentStyle');
            if numel(rhs) > 2
                error(message('MATLAB:textscan:NonStringCellsInCommentStyle'))
            end
            opts.comments_ = rhs;
        end
        
        function val = get.CommentStyle(opts)
            val = matlab.io.internal.utility.unescape(opts.comments_);
        end
    end
end
