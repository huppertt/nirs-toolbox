function outStr = removePrefixSuffix(inStr,prefixes,suffixes)
% REMOVEPREFIXSUFFIX utility function to remove prefixes and suffixes from spreadsheet variables

% Copyright 2017 The MathWorks, Inc.

% convert prefixes and suffixes to cellstr
if ~isempty(prefixes)
    prefixes = cellstr(prefixes);
end

if ~isempty(suffixes)
    suffixes = cellstr(suffixes);
end

% use string API to remove prefixes and suffixes
outStr = cell(size(inStr,1),size(inStr,2));
for ii = 1 : size(inStr,1)
    % copy input string into the output string
    outStr{ii} = inStr{ii};
    % remove prefixes
    for jj = 1 : size(prefixes,2)
        isPrefix = startsWith(inStr{ii},prefixes{jj});
        if isPrefix
            outStr{ii} = replaceBetween(inStr{ii},1,length(prefixes{jj}),'');
            break;
        end
    end
    % remove suffixes
    for jj = 1 : size(suffixes,2)
        isSuffix = endsWith(inStr{ii},suffixes{jj});
        if isSuffix
            widths = length(outStr{ii});
            outStr{ii} = replaceBetween(outStr{ii},widths - length(suffixes{jj})+1,widths,'');
            break;
        end
    end
end
end