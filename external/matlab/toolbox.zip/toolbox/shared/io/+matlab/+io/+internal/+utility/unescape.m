function strings = unescape(strings)
%UNESCAPE Replace escaped characters with their escape sequences

% Copyright 2015-2016, The MathWorks, Inc.

persistent uninterpreted interpreted N
if isempty(uninterpreted)
    uninterpreted = {'''';'%%';'\\';'\a';'\b';'\f';'\n';'\r';'\t';'\v'};
    interpreted = cellfun(@sprintf,uninterpreted,'UniformOutput',false);
    N = length(uninterpreted);
end 

    function str = unescapestring(str)
        for j = 1:N
            % can't be vectorized, need to do this iteratively
            str = strrep(str,interpreted{j},uninterpreted{j});
            % wanted this, but \a (and others) fail.
            % str = regexprep(str,interpreted,uninterpreted);
        end
    end

if ~( matlab.io.internal.validators.isString(strings) ...
   || matlab.io.internal.validators.isCellOfStrings(strings(:)))
    error(message('MATLAB:textio:textio:InvalidStringOrCellStringProperty','inputs'));
end

if iscell(strings)
    strings = cellfun(@unescapestring,strings,'UniformOutput',false);
else
    strings = unescapestring(strings);
end

end

