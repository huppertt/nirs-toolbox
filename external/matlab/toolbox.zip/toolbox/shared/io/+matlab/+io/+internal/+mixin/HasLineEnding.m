classdef (HandleCompatible) HasLineEnding
%HASDELIMITER a text.mixin class for the Delimiter property

% Copyright 2016 The MathWorks, Inc.
    
    properties (Dependent)
        %LINEENDING Symbol(s) which indicate the end of a line.
        LineEnding
    end
    
    properties (Access = private)
        % This contains interpreted characters, not the escape sequences
        eol_ = {newline,char(13),char([13 10])};
    end
    
    methods
        function opts = set.LineEnding(opts,rhs)
            rhs = convertStringsToChars(rhs);
            rhs = matlab.io.internal.utility.validateAndEscapeCellStrings(rhs,'LineEnding');
            opts.eol_ = unique(rhs);
        end
        
        function val = get.LineEnding(opts)
            val = matlab.io.internal.utility.unescape(opts.eol_(:))';
        end
    end
end
