function tf = isString(x)
%isString  True for a character string.
%   This function returns true if x is a row character array and false
%   otherwise.
%
%   Copyright 2016-2017 The MathWorks, Inc.

tf = ischar(x) && ( isrow(x) || isequal(x, '') );
end
