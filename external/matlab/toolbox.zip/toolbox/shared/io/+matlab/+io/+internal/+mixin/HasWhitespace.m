classdef (HandleCompatible) HasWhitespace
%HASWHITESPACE a text.mixin class for the Whitespace property

% Copyright 2016 The MathWorks, Inc.

    properties (Dependent)
        %WHITESPACE Characters to be treated as whitespace
        % See Also matlab.io.TextVariableImportOptions/WhitespaceRule
        Whitespace
    end
    
    properties (Access = private)
        % This contains interpreted characters, not the escape sequences
        whtspc_ = sprintf('\b\t ');
    end
    
    methods
        function obj = set.Whitespace(obj,whitespace)
            whitespace = convertStringsToChars(whitespace);
            whitespace = matlab.io.internal.utility.validateAndEscapeStrings(whitespace,'Whitespace');
            obj.whtspc_ = unique(whitespace);
        end
        
        function whitespace = get.Whitespace(obj)
            % Array might be row or column, don't bother trying to 
            % keep the state fixed as a column, but reorient it on return.
            % This will always produce a row.
            whitespace = matlab.io.internal.utility.unescape(obj.whtspc_(:)'); 
        end
    end
end
