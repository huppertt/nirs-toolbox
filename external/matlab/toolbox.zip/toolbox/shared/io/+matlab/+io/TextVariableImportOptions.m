classdef TextVariableImportOptions < matlab.io.VariableImportOptions
    %TEXTVARIABLEIMPORTOPTIONS options for importing text variables
    %   topts = matlab.io.TextVariableImportOptions(...)
    %
    %   TextVariableImportOptions properties:
    %               Name - The name of the variable on import
    %               Type - The data type of the variable on import
    %          FillValue - A scalar value to fill missing or unconvertible data 
    %     TreatAsMissing - Text which is used in a file to represent missing
    %                      data, e.g. 'NA'
    %          QuoteRule - How to treat quoted text
    %     WhitespaceRule - How to treat whitespace surrounding text
    %
    %   See also matlab.io.VariableImportOptions
    
    % Copyright 2016 The MathWorks, Inc.
    properties
        %WHITESPACERULE
        %   Rules for dealing with leading and trailing whitespace when importing
        %   text data.
        %   'trim' - (default) Any leading or trailing whitespace is removed from
        %            the text. Interior whitespace is unaffected.
        %
        %   'trimleading' - Only the leading whitespace will be removed.
        %
        %   'trimtrailing' - Only the trailing whitespace will be removed.
        %
        %   'preserve' - No whitespace will be removed.
        %
        %   See also matlab.io.TextVariableImportOptions
        WhitespaceRule = 'trim';
        
        %TYPE
        %
        %   See also matlab.io.TextVariableImportOptions
        Type = 'char';
        
        %FILLVALUE
        %   A character vector to be used as a placeholder when data is missing or
        %   matches a value in TreatAsMissing, and MissingRule='fill'.
        %
        %   See also matlab.io.TextVariableImportOptions
        FillValue = [];
    end
    
    methods
        function obj = TextVariableImportOptions(varargin)
            %TextVariableImportOptions options for importing text variables.
            [obj,otherArgs] = obj.parseInputs(varargin);
            obj.assertNoAdditionalParameters(fields(otherArgs),class(obj));
        end
        
        function obj = set.WhitespaceRule(obj,rhs)
            rhs = convertStringsToChars(rhs);
            obj.WhitespaceRule = validatestring(rhs,{'trim','trimleading','trimtrailing','preserve'});
        end
        
        function obj = set.Type(obj,rhs)
            try
                obj.Type = validatestring(rhs,{'char','string'});
            catch ME
                import matlab.io.internal.supportedTypeNames
                if strcmp(ME.identifier,'MATLAB:unrecognizedStringChoice') && any(strcmp(supportedTypeNames,rhs))
                    % additional information to help with debugging
                    newMsg = ['\n\n',getString(message('MATLAB:textio:io:Setdatatype')), '\n', ...
                        getString(message('MATLAB:textio:io:SetvartypeSyntax',obj.Name,rhs))];
                    throw(MException('MATLAB:unrecognizedStringChoice',[ME.message, newMsg]));
                end
                throw(ME);
            end
        end
        
        function val = get.FillValue(obj)
            val = obj.FillValue;
            if isnumeric(val)
                switch obj.Type 
                case 'char'
                    val = '';
                case 'string'
                    val = string(missing);
                end
            else
                switch obj.Type 
                case 'char'
                    val = cellstr(val);
                    val = char(val{1});
                case 'string'
                    val = string(val);
                end    
            end
        end
        function obj = set.FillValue(obj,rhs)
            % Only accept cellstr with 1 char element.
            if iscell(rhs) && isscalar(rhs) && ischar(rhs{1})
                rhs = rhs{1};
            end
                
            if ~(isstring(rhs) && isscalar(rhs))...
            && ~(ischar(rhs) && (isrow(rhs) || isequal(rhs, '')))...
            && ~(isa(rhs,'missing') && isscalar(rhs))
                error(message('MATLAB:textio:io:FillValueText'));
            end
            
            switch obj.Type %#ok<MCSUP>
                case 'char'
                    if isa(rhs,'missing')
                        obj.FillValue = '';
                    else 
                        obj.FillValue = char(rhs);
                    end
                case 'string'
                    obj.FillValue = string(rhs);
            end
        end
    end
    
    methods (Access = protected)
        function [type_specific,group_name] = getTypedPropertyGroup(obj)
            group_name = 'String Options:';
            type_specific.WhitespaceRule = obj.WhitespaceRule;
        end
    end
    
    methods (Sealed,Hidden)
        function [var,errid,placeholder] = readSpreadsheetVariable(varopts,sheet,subrange,typeIDs)
            if strcmp(varopts.Type, 'string')
                treatAsMissingVals = string(varopts.TreatAsMissing);
                % Create an empty vector to hold our results
                var = strings(size(typeIDs));
            else
                treatAsMissingVals = varopts.TreatAsMissing;
                % Create an empty vector to hold our results
                var = repmat({''},size(typeIDs));
            end
            
            % Initialize errid logical vector
            errid = false(size(typeIDs));
            placeholder = errid;
            textmask = typeIDs == sheet.STRING;
            if any(textmask(:))
                data = sheet.readStrings(subrange,varopts.Type);
                if ~isempty(treatAsMissingVals)
                    placeholder(ismember(strip(data),treatAsMissingVals)) = true;
                end
                var(textmask) = data(textmask);
            else
                placeholder = false(size(typeIDs));
            end
            
            datemask = typeIDs == sheet.DATETIME;
            if any(datemask(:))
                complexRepDates = sheet.readDates(subrange);
                dates = matlab.io.spreadsheet.internal.createDatetime(complexRepDates(datemask), 'default', '');
                var(datemask) = cellstr(dates, [], 'system');
            end
            
            boolmask = typeIDs == sheet.BOOLEAN;
            if any(boolmask(:))
                % Convert to 'true' and 'false'
                values = {'true'; 'false'};
                data = sheet.readBooleans(subrange);
                var(boolmask) = values(2 - data(boolmask),:);
            end
            
            numbermask = typeIDs == sheet.NUMBER;
            if any(numbermask(:))
                data = sheet.readNumbers(subrange);
                data(~numbermask) = [];
                strdata = num2str(data(:));
                var(numbermask) = strtrim(cellstr(strdata));
            end
            
            switch varopts.WhitespaceRule
                case 'trim'
                    var = strip(var,'both');
                case 'trimleading'
                    var = strip(var,'left');
                case 'trimtrailing'
                    var = strip(var,'right');
                case 'preserve'
                    % Do nothing
            end
            var(textmask) = varopts.handleQuotes(var(textmask));
            if ~isempty(varopts.Prefixes) || ~isempty(varopts.Suffixes)
                import matlab.io.internal.utility.removePrefixSuffix
                var(textmask) = removePrefixSuffix(var(textmask),varopts.Prefixes,varopts.Suffixes);
            end
        end
    end
end

