function string = validateAndEscapeStrings( string , propertyname )
% VALIDATEESCAPEDSTRINGS validate and transform input strings

% Copyright 2015-2016, The MathWorks, Inc.

if ~matlab.io.internal.validators.isString(string)
    error(message('MATLAB:textio:textio:InvalidStringProperty',propertyname));
end
string = sprintf(string);
end

