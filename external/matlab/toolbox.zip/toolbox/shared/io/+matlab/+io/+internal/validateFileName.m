function [validFileNames, fileExtensions] = validateFileName(fileName, varargin)
%VALIDATEFILENAME Validate the existence of a specified file.
%   Validate the existence of a file named FILENAME by searching through
%   the filesystem. First, check if FILENAME is a valid absolute or
%   relative path to a file. Otherwise, check for a file named FILENAME on
%   the MATLAB path.
%
%   varargin: Optionally, specify a list of file extensions to search for
%             as a cell array of character vectors.
%
%             For example, if FILENAME == 'myFile' and VARARGIN{1} == {'.txt', '.csv'},
%             then VALIDATEFILENAME will check for the existence of the following
%             files, in the order specified below:
%
%               1. 'myFile'
%               2. 'myFile.txt'
%               3. 'myFile.csv'
%
% VALIDATEFILENAME will return all file names matching the specified
% validation criteria as VALIDFILENAMES, along with their
% corresponding file extensions as FILEXTENSIONS.

fileName = convertStringsToChars(fileName);
fileNamesToBeValidated = {fileName};
validFileNames = {};

% Check if additional file extensions were provided. If so, generate
% additional file names for validation.
if nargin > 1
    [varargin{:}] = convertStringsToChars(varargin{:});
    extensions = varargin{1};
    additionalFileNames = generateFileNamesWithFileExtensions(fileName, extensions);
    fileNamesToBeValidated = [fileNamesToBeValidated, additionalFileNames];
end

% Validate file names.
for ii = 1:numel(fileNamesToBeValidated)
    fn = fileNamesToBeValidated{ii};
    % Check whether tempFileName is a valid absolute path
    % or relative path to an existing file.
    if isfile(fn)
        validFileNames = [validFileNames, fn];
    else
        fn = validateFileNameOnMATLABPath(fn);
        if ~isempty(fn)
            validFileNames = [validFileNames, fn];
        end
    end
end

% If no valid files were found, then error.
if isempty(validFileNames)
    error(message('MATLAB:textio:textio:FileNotFound', fileName));
end

% Get file extensions of valid file names.
fileExtensions = cell(1, numel(validFileNames));
for ii = 1:numel(validFileNames)
    [~, ~, ext] = fileparts(validFileNames{ii});
    fileExtensions{ii} = ext;
end

% Return only unique file names and extensions.
validFileNames = unique(validFileNames, 'stable')';
fileExtensions = unique(fileExtensions, 'stable')';

end

function fn = validateFileNameOnMATLABPath(fileName)
[~, ~, ext] = fileparts(fileName);
% "which" can be used to search for files with an extension
% on the MATLAB path.
if ~isempty(ext)
    tempFileName = which(fileName);
    [~, ~, tempExt] = fileparts(tempFileName);
    if ~isempty(tempFileName) && strcmp(ext, tempExt)
        fn = tempFileName;
    else
        fn = '';
    end
else
    % "fopen" can be used to search for files without an extension
    % on the MATLAB path.
    fid = fopen(fileName);
    if fid ~= -1
        tempFileName = fopen(fid);
        fclose(fid);
        fn = tempFileName;
    else
        fn = '';
    end
end
end

function fns = generateFileNamesWithFileExtensions(fileName, extensions)
fns = cell(1, numel(extensions));
% Append each extension to the base file name.
for ii = 1:numel(extensions)
    extension = extensions{ii};
    % Add a dot separating the base file
    % name and the file extension.
    if ~isempty(extension) && extension(1) ~= '.'
        extension = ['.', extension];
    end
    fns{ii} = strcat(fileName, extension);
end
end