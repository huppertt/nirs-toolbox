function cellstrings = validateAndEscapeCellStrings( cellstrings,propertyname )
% VALIDATEESCAPEDCELLSTRINGS validate and transform input cell string 

% Copyright 2015-2016, The MathWorks, Inc.

if ~( matlab.io.internal.validators.isString(cellstrings) ...
   || matlab.io.internal.validators.isCellOfStrings(cellstrings(:)))
    error(message('MATLAB:textio:textio:InvalidStringOrCellStringProperty',propertyname));
end
if ischar(cellstrings)
    cellstrings = {cellstrings};
end
cellstrings = cellfun(@sprintf,cellstrings,'UniformOutput',false);
end

