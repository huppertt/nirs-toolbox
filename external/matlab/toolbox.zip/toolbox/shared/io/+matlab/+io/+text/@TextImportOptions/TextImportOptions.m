classdef (AllowedSubclasses = {?matlab.io.text.DelimitedTextImportOptions,?matlab.io.text.FixedWidthImportOptions}) TextImportOptions < matlab.io.ImportOptions ...
        & matlab.io.internal.mixin.HasLineEnding ...
        & matlab.io.internal.mixin.HasCommentStyle
    
    % Copyright 2016-2018 MathWorks, Inc.
    
    properties
        %DATALINES the lines in the text file where the data is located.
        % DataLines must be a non-negative scalar integer or a Nx2 array of
        % non-negative integers.
        DataLines = [1, inf];
        
        %VARIABLENAMELINE the line in the file that contains the variable
        % names.
        % VariableNamesLine must be a non-negative scalar integer.
        VariableNamesLine = 0;
        
        %ROWNAMESCOLUMN the column that contains row names describing the
        % data.
        % RowNamesColumn must be a non-negative scalar integer.
        RowNamesColumn = 0;
        
        %VARIABLEUNITSLINE the line in the file that contains the variable
        % units.
        % VariableUnitsLine must be a non-negative scalar integer.
        VariableUnitsLine = 0;
        
        %VARIABLEDESCRIPTIONSLINE the line in the file that contains the
        % variable descriptions.
        % VariableDescriptionsLine must be a non-negative scalar integer.
        VariableDescriptionsLine = 0;
        
        %EXTRACOLUMNSRULE what to do with extra columns of data that appear
        % after the expected variables.
        %
        %   Possible values:
        %       addvars: Create a new variable in the resulting table
        %                containing the data from the extra columns. The
        %                new variables are named 'ExtraVar1', 'ExtraVar2',
        %                etc..
        %
        %        ignore: Ignore the extra columns of data.
        %
        %          wrap: Wrap the extra columns of data to new records.
        %                This does not change the number of variables.
        %
        %         error: Error during import and abort the operation.
        ExtraColumnsRule = 'addvars';
        
        %EMPTYLINERULE what to do with empty lines in the file.
        %
        %   Possible values:
        %          skip: Skip empty lines.
        %
        %          read: Read empty lines as you would non-empty lines.
        %
        %         error: Error during import and abort the operation.
        EmptyLineRule = 'skip';
        
        %ENCODING the character encoding used to interpret the bytes as text.
        %  Use the flag, 'system' to prefer the default system encoding
        %
        % See also fopen
        Encoding = 'system';
    end

    properties (Dependent, Hidden)
        DataLine
    end
    
    % Getters and Setters
    methods
        function opts = set.DataLines(opts,rhs)
            if isscalar(rhs)
                try
                    opts.DataLines = validateLineNumber(rhs);
                catch ME
                    error(message('MATLAB:textio:io:InvalidDataLines'));
                end
            else
                if ~isnumeric(rhs)
                    error(message('MATLAB:textio:io:InvalidDataLines'));
                end
                try
                    opts.DataLines = matlab.io.internal.validators.validateLineIntervals(rhs,'DataLines');
                catch ME
                    throwAsCaller(ME);
                end
            end
        end
        
        function opts = set.VariableNamesLine(opts,rhs)
            try
                opts.VariableNamesLine = validateLineNumber(rhs);
            catch ME
                throwAsCaller(ME);
            end
        end
        
        function opts = set.RowNamesColumn(opts,rhs)
            n = validateLineNumber(rhs);
            if n > numel(opts.VariableNames)
                error(message('MATLAB:textio:io:RowNamesColNumVars'))
            end
            opts.RowNamesColumn = n;
        end
        
        function opts = set.VariableUnitsLine(opts,rhs)
            try
                opts.VariableUnitsLine = validateLineNumber(rhs);
            catch ME
                throwAsCaller(ME);
            end
        end
        
        function opts = set.VariableDescriptionsLine(opts,rhs)
            try
                opts.VariableDescriptionsLine = validateLineNumber(rhs);
            catch ME
                throwAsCaller(ME);
            end
        end
        
        function opts = set.ExtraColumnsRule(opts,rhs)
            try
                opts.ExtraColumnsRule = validatestring(rhs,{'addvars','ignore','wrap','error'});
            catch ME
                throwAsCaller(ME);
            end
        end
        
        function opts = set.EmptyLineRule(opts,rhs)
            try
                opts.EmptyLineRule = validatestring(rhs,{'skip','read','error'});
            catch ME
                throwAsCaller(ME)
            end
        end
        
        function opts = set.Encoding(opts,rhs)
            try
                if ~strcmp(rhs,'system')
                    fclose(fopen([mfilename('fullpath') '.m'],'r','n',rhs));
                end
            catch ME
                throwAsCaller(ME)
            end
            opts.Encoding = convertStringsToChars(rhs);
        end

        function opts = set.DataLine(opts,rhs)
            opts.DataLines = rhs;
        end
        
        function lhs = get.DataLine(opts)
            lhs = opts.DataLines;
        end
    end
    
    methods (Hidden, Static, Access = protected)
        function args = parseReadtableInputs(args)
            persistent parser
            if isempty(parser)
                parser = inputParser();
                parser.FunctionName = 'readtable';
                parser.addParameter('FileEncoding','');
                parser.addParameter('Encoding','');
                parser.addParameter('DateLocale','');
                parser.addParameter('ReadVariableNames',[]);
                parser.addParameter('ReadRowNames',[]);
            end
            parser.parse(args{:});
            args = parser.Results;
            % Encoding and FileEncoding map to the same property
            if any(strcmp('Encoding',parser.UsingDefaults))
                args.Encoding = args.FileEncoding;
            end
        end
    end
    
    methods (Sealed, Access = protected)
        function verifyMaxVarSize(~,~)
        end
        
        function opts = setRowNames(opts,usedefault)
            if usedefault
                opts.RowNamesColumn = 1;
            else
                opts.RowNamesColumn = 0;
            end
        end
        
        function tf = usingRowNames(opts)
            tf = (opts.RowNamesColumn > 0);
        end
        
        function [opts,rowNamesID,rowNamesAsVariable] = deselectRowNames(opts,rrn)
            % make sure that row names being pulled from one of the variables is a selected
            % variable. The data will be read as char later.
            rowNamesID = opts.RowNamesColumn;
            rowNamesAsVariable = true;
            if rowNamesID > 0
                [isSelected,selectedID] = ismember(opts.VariableNames(rowNamesID),opts.SelectedVariableNames);
                if isSelected
                    % The row-names are already a selected variable/ adjust the column to match the
                    % selected indices.
                    rowNamesID = selectedID;
                    [opts,rowNamesAsVariable,rowNamesID] = deselectSelectedRownames(opts,rrn,rowNamesID);
                else
                    % The row-names var is not selected, add it and find the right index to use.
                    opts.SelectedVariableNames = [opts.SelectedVariableNames opts.VariableNames{rowNamesID}];
                    rowNamesID = numel(opts.SelectedVariableNames);
                    rowNamesAsVariable = false;
                end
            end
        end
    end
    
    methods (Hidden)
        
        function T = readtable(filename,opts,varargin)
            remote2Local = matlab.virtualfileio.internal.stream.RemoteToLocal(filename);
            filename = remote2Local.LocalFileName;
            [filename,opts,rrn,rvn,args] = matlab.io.ImportOptions.validateReadtableInputs(filename,opts,varargin);
            args = opts.parseReadtableInputs(args);
            
            % Use the override encoding
            if ~isempty(args.Encoding)
                opts.Encoding = args.Encoding;
            end
            
            % Use the system encoding
            if strcmp(opts.Encoding,'system')
                lc = feature('locale');
                opts.Encoding = lc.encoding;
            end
            
            % Use the override date locale.
            if ~isempty(args.DateLocale)
                % Validate the locale
                matlab.io.DatetimeVariableImportOptions('DatetimeLocale',args.DateLocale);
                dates = strcmp(opts.VariableTypes,'datetime');
                if any(dates)
                    opts = opts.setvaropts(dates,'DatetimeLocale',args.DateLocale);
                end
            end
            % If the RowNames are coming from a column which isn't being
            % imported, add the RowNamesColumn to the beginning.
            
            [opts,rowNamesID,rowNamesAsVariable] = opts.deselectRowNames(rrn);

            % create the internal parser.
            parser = matlab.io.internal.text.TableParser(filename,opts);
            
            % Read Names
            if opts.VariableNamesLine > 0 && rvn
                names = readVariableNames(parser);
            else
                names = opts.SelectedVariableNames;
            end
            
            % Read Metadata
            units = readVariableUnits(parser);
            descr = readVariableDescriptions(parser);
            
            % Read the data
            [data,numextra,omit_rows,omit_vars,dates] = readData(parser);
            
            % If we receive a date column containing all NaTs, suggest that
            % they change the datetime variable InputFormat.
            dateCols = [data{dates}];
            if ~isempty(dateCols) && any(all(isnat(dateCols)))
                warning(message('MATLAB:readtable:AllNaTVariable'));
            end
            
            [data,rownames,rowDimName,names,units,descr] = matlab.io.internal.utility.removeRowNamesFromVariables(rowNamesID,data,names,units,descr,opts.SelectedVariableNames,rowNamesAsVariable);

            if numextra > 0
                % Add Extra columns
                trailingnames = arrayfun(@(d){sprintf('ExtraVar%d',d)},(1:numextra));
                names = [names matlab.lang.makeUniqueStrings(trailingnames,names,namelengthmax)];
                if ~isempty(units), units((end+1):numel(names))={''}; end
                if ~isempty(descr), descr((end+1):numel(names))={''}; end
            end
            
            % if the variable being set as RowNames is not char, convert to
            % char, so there is no loss of data.
            if opts.RowNamesColumn ~= 0 && ~any(strcmp(opts.VariableTypes(opts.RowNamesColumn),{'char','string'}))
                opts.VariableTypes(opts.RowNamesColumn) = {'char'};
                % create the internal parser again.
                opts.SelectedVariableNames = opts.RowNamesColumn;
                opts.RowNamesColumn = 0;
                parser = matlab.io.internal.text.TableParser(filename,opts);
                rownames = readData(parser);
                rownames = rownames{1};
                emptyIDS = ~(strlength(rownames)>0);
                rownames(emptyIDS) = arrayfun(@(i) {sprintf('Row%d',i)},find(emptyIDS));
                rownames = matlab.lang.makeUniqueStrings(cellstr(rownames));
            end

            % Create the table
            T = table(data{:},...
                'VariableNames',names,...
                'RowNames',rownames);
            
            % Set the metadata
            T.Properties.VariableUnits = units;
            T.Properties.VariableDescriptions = descr;
            
            % Remove omitted rows and vars
            if ~isempty(omit_rows(:)), T(omit_rows,:) = []; end
            if ~isempty(omit_vars(:)), T(:,omit_vars) = []; end
            
            % Make the dimension names unique with respect to the var names
            dimNames = T.Properties.DimensionNames;
            if ~isempty(rowDimName)
                dimNames{1} = rowDimName;
            end
            T.Properties.DimensionNames = matlab.lang.makeUniqueStrings(dimNames,names,namelengthmax);
        end
    end
end

function rhs = validateLineNumber(rhs)
if ~isnumeric(rhs) || ~isscalar(rhs) || floor(rhs) ~= rhs || rhs < 0 || isinf(rhs)
    error(message('MATLAB:textio:textio:ExpectedScalarInt'));
end
rhs = double(rhs);
end
