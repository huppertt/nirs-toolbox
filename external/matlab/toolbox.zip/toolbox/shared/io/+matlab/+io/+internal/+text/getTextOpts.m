function opts = getTextOpts(filename,emptyColType,args)
%   This function is called from readtable and detectImportOptions, and in
%   turn calls detectFormatOptions to return the datatypes, and construct the
%   Import Options object.

%   Copyright 2017-2018 The MathWorks, Inc.

    import matlab.io.internal.utility.validateAndEscapeCellStrings;
    import matlab.io.internal.utility.validateAndEscapeStrings;
    additionalArgs = {};
    names = fieldnames(args);

    locale = {};
    numVars = [];
    nheaders = [];
    for f = 1 : size(names,1)
        if strcmp(names{f},'DatetimeLocale')
            locale = args.DatetimeLocale;
            continue;
        elseif strcmp(names{f},'NumHeaderLines')
            nheaders = args.NumHeaderLines;
            continue;
        elseif strcmp(names{f},'NumVariables')
            numVars = args.NumVariables;
            continue;
        end
        additionalArgs{end + 1} = names{f}; %#ok<AGROW>
        additionalArgs{end + 1} = args.(names{f}); %#ok<AGROW>
    end
    % The options need to have the property value of encoding == to 'system' if
    % a user passes in 'system', otherwise, set the ecoding specifically to
    % what was used to detect other parameters.
    lc = feature('locale');
    opts = matlab.io.text.DelimitedTextImportOptions('Encoding',lc.encoding,additionalArgs{:});
    useSystemEncoding = strcmp(opts.Encoding,'system');
    if useSystemEncoding
        % Using literal 'system' encoding, preserve that, but use the real-value
        % for detection.
        opts.Encoding = lc.encoding; 
    end
    if ~isempty(numVars)
        additionalArgs{end + 1} = 'NumVariables';
        additionalArgs{end + 1} = numVars;
        opts.VariableOptions(1:numVars) = matlab.io.TextVariableImportOptions;
    end
    if ~isempty(nheaders)
        additionalArgs{end + 1} = 'NumHeaderLines';
        additionalArgs{end + 1} = nheaders;
    end
    if isempty(locale)
        locale = matlab.internal.datetime.getDefaults('locale');
    end
    
    BOM = matlab.io.internal.text.checkBOMFromFilename(filename);
    % If the file has a BOM for UTF-8, and the encoding is SYSTEM, or
    % default, silently switch to UTF-8 otherwise, if the BOM doesn't match
    % the expected encoding, warn.
    if (~any(strcmp(names,'Encoding')) || strcmp(args.Encoding,'system')) ...
            && strcmp(BOM.Encoding,'UTF-8')
        opts.Encoding = 'UTF-8';
    elseif ~isempty(BOM.Encoding) && ~strcmp(opts.Encoding,BOM.Encoding)
        matlab.io.internal.utility.warnOnBOMmismatch(BOM,opts.Encoding);
    end
    
    strat = matlab.io.internal.text.detectFormatOptions(filename, ...
        additionalArgs{:},'Encoding',opts.Encoding,'DateLocale',locale);

    if strcmp(strat.Mode,'Delimited')
        opts.Delimiter = strat.Delimiter;
        c = compose(opts.Delimiter); % get the actual characters, not the escape sequences
        scalar_delims = (strlength(c)==1);
        if any(scalar_delims) % Remove scalar whitespace values which were delimiters
            opts.Whitespace = setdiff(sprintf(opts.Whitespace),[c{scalar_delims}]);
        end
    elseif strcmp(strat.Mode,'SpaceAligned')
        opts.Delimiter = {' ','\t'};
        opts.ConsecutiveDelimitersRule = 'join';
        opts.LeadingDelimitersRule = 'ignore';
        opts.Whitespace = '\b'; %Using textscan defaults for compatibility

    elseif strcmp(strat.Mode,'FixedWidth')
        opts = matlab.io.text.FixedWidthImportOptions('VariableOptions',...
            repmat(matlab.io.TextVariableImportOptions,numel(strat.Widths),1),...
            'VariableWidths',strat.Widths,...
            additionalArgs{:},...
            'Encoding',opts.Encoding);
    else % Line reader
        opts.Delimiter = {','};
        strat.NumHeaderLines = 0;
        strat.Types = 2;
    end

    ids = strat.Types;
    ids(1:strat.NumHeaderLines,:) = [];

    [types, metaRows, emptyCols] = matlab.io.spreadsheet.internal.detectTypes(ids,emptyColType);
    if strcmp(strat.Mode,'FixedWidth')
        opts.VariableWidths(emptyCols-1) = sum(opts.VariableWidths(emptyCols-1:end));
        opts.VariableWidths(emptyCols:end) = [];
    end
    types(emptyCols:end) = [];
    if isempty(types)
        opts.VariableNames = {};
    else
        opts.VariableOptions = getVarOptsArrayFromTypes(types,arrayfun(@(c){sprintf('Var%d',c)},1:(numel(types))));
    end

    opts.DataLines = [strat.NumHeaderLines + 1 + metaRows, inf];
    opts.VariableNamesLine = (metaRows > 0) * (strat.NumHeaderLines + 1);

    if (metaRows > 0)
        p = matlab.io.internal.text.TableParser(filename,opts);
        numNames = numel(opts.VariableNames);
        names = p.readVariableNames();
        idx = 1:min(numNames,numel(names));
        opts.VariableNames(idx) = names(idx);
    end

    if ~isempty(numVars)
        opts.VariableNames = opts.VariableNames(1:min([numel(opts.VariableNames),numVars]));
        opts.ExtraColumnsRule = 'ignore';
    end

    % set back to literal 'system'
    if useSystemEncoding
        opts.Encoding = 'system';
    end

end

function varopts = getVarOptsArrayFromTypes(types,names)
import matlab.io.*;
persistent optsPrototypes
if isempty(optsPrototypes)
    optsPrototypes = [TextVariableImportOptions;
        NumericVariableImportOptions;
        DatetimeVariableImportOptions
        DurationVariableImportOptions];
end
[~,id ] = ismember(types,{'char','double','datetime','duration'});
varopts = setNames(optsPrototypes(id),names);

end