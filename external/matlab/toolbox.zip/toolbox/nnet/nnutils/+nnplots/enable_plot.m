function enable_plot(plotData)

% Copyright 2010 The MathWorks, Inc.
set(plotData.CONTROL.text,'string','','visible','off');
