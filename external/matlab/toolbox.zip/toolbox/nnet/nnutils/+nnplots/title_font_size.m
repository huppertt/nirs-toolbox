function n = title_font_size
%NN_PLOT_TITLE_FONT_SIZE Standard NNET plot title font size.

% Copyright 2010 The MathWorks, Inc.

n = 12;
