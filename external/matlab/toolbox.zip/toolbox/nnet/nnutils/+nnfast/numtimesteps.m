function ts = numtimesteps(x)
%NUMTIMESTEPS_FAST (STRICTNNDATA)

% Copyright 2010 The MathWorks, Inc.

ts = size(x,2);
