function treestruct = myPEGparser(str,rules)
%*************************************************************
            % Meaning of s and t:
            %
            % treestruct = classreg.regr.LinearMixedFormula.p.parse(f.str); 
            %
            %  s = treestruct.string = Formula string entered by the user
            %  t = treestruct.tree   = parse tree of recorded rules
            %
            %  t is a 5-by-N array of integers. Each column represents a 
            %  node in the tree with rows containing the following info:
            %      rule number for node
            %      start index of match for node
            %      end index of match for node
            %      offset to parent (subtract) of node
            %      number of nodes in the subtree rooted at the node
            %  Any child nodes start directly to the right of the parent
            %  node and appear in order left to right. Thus the entire
            %  subtree rooted at node N is between columns N and
            %  N+TREE(5,N)-1, inclusive.
            %**************************************************************
            
treestruct.str=str;

numnodes=5;

%formula
t(1,1)=rules.Formula;
t(1,2)=1;
t(1,3)=length(str);
t(1,4)=0;
t(1,5)=numnodes+2+1;

% response
t(2,1)=rules.Response;
t(2,2)=1;
t(2,3)=strfind(str,'~')-1;
t(2,4)=1;
t(2,5)=2;

% response var
resp=str(strfind(str,'~')-1);
resp=strtrim(resp);
t(3,1)=rules.ResponseVar;
t(3,2)=1;
t(3,3)=length(resp);
t(3,4)=1;
t(3,5)=1;


% Predictor
pred=str(strfind(str,'~')-1);
t(4,1)=rules.Predictor;
t(4,2)=strfind(str,'~')+1;
t(4,3)=length(str)-strfind(str,'~');
t(4,4)=1;
t(4,5)=numnodes+1;









treestruct.tree=t';


